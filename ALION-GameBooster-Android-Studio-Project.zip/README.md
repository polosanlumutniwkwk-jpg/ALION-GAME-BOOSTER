# ALION - Android Game Booster & Performance Engine

ALION is a high-performance Android Game Booster built with Kotlin and Jetpack Compose.
Inspired by professional gaming tools like ZAYON Response, it provides real hardware telemetry,
Game Space profiles, screen refresh rate negotiation, floating HUD overlays, touchscreen diagnostic
labs, and Shizuku ADB privileged integration.

## Key Capabilities
1. **Home Dashboard**: Real-time CPU cluster frequencies, Adreno/Mali GPU metrics, RAM breakdown (Active, Cached, zRAM), UFS storage speeds, battery thermal state.
2. **Game Space**: Installed games detection, custom per-game profiles, target FPS selection, resolution scale, one-tap boost launcher.
3. **Graphics Control**: DisplayManager refresh rate switching (60Hz, 90Hz, 120Hz, 144Hz), resolution scaling via WindowManager, frame pacer.
4. **Floating Game Tools**: Draggable System Alert Window overlay HUD with real-time FPS, CPU, RAM, Ping, and customizable tactical crosshairs.
5. **Game Lab**: Touchscreen testing suite (multi-touch tracking, touch accuracy bulls-eye, deadzone boundary test, ghost touch diagnostic, latency benchmark).
6. **Accessibility & System Access**: Granular permission manager, Shizuku integration for rootless ADB privileged commands, Wireless Debugging guide.
7. **Clean Architecture**: Kotlin, Jetpack Compose, MVVM, Coroutines, StateFlow, Android 15 & 16 ready.

## Building the APK in Android Studio
1. Open Android Studio (Ladybug 2024.2+ or Meerkat).
2. Choose **Open Project** and select this directory.
3. Allow Gradle sync to complete.
4. Run on a physical Android device:
   ```bash
   ./gradlew assembleDebug
   ```
   The debug APK will be generated at:
   `app/build/outputs/apk/debug/app-debug.apk`

5. To generate a signed Release APK:
   ```bash
   ./gradlew assembleRelease
   ```

## Shizuku Integration
If Shizuku is installed and running on your Android device:
- ALION communicates with `rikka.shizuku.Shizuku` binder to execute `wm size` and `settings` modifications without requiring root access.
