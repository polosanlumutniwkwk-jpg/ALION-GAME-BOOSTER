package com.alion.gamebooster.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AlionColors.ElectricBlue,
    secondary = AlionColors.NeonCyan,
    background = AlionColors.BackgroundDark,
    surface = AlionColors.SurfaceDark,
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onBackground = AlionColors.TextPrimary,
    onSurface = AlionColors.TextPrimary,
    outline = AlionColors.BorderDark
)

@Composable
fun ALIONTheme(
    darkTheme: Boolean = true, // ALION defaults to premium gaming dark
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}