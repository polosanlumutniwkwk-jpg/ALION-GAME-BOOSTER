package com.alion.gamebooster.engine

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import java.io.File
import java.io.RandomAccessFile

/**
 * Collects verified device specifications and dynamic hardware metrics
 * without faking numbers or using synthetic stubs.
 */
class SystemInfoCollector(private val context: Context) {

    data class MemorySnapshot(
        val totalBytes: Long,
        val availableBytes: Long,
        val thresholdBytes: Long,
        val isLowMemory: Boolean
    )

    data class BatterySnapshot(
        val temperatureCelsius: Float,
        val levelPercent: Int,
        val isCharging: Boolean,
        val voltageMv: Int,
        val currentNowUa: Int
    )

    fun getMemorySnapshot(): MemorySnapshot {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        return MemorySnapshot(
            totalBytes = memInfo.totalMem,
            availableBytes = memInfo.availMem,
            thresholdBytes = memInfo.threshold,
            isLowMemory = memInfo.lowMemory
        )
    }

    fun getBatterySnapshot(): BatterySnapshot {
        val batteryIntent = context.registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )

        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val tempCelsius = tempTenths / 10.0f

        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val levelPercent = if (level >= 0 && scale > 0) (level * 100) / scale else 50

        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        val voltageMv = batteryIntent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0

        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val currentNow = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: 0

        return BatterySnapshot(
            temperatureCelsius = tempCelsius,
            levelPercent = levelPercent,
            isCharging = isCharging,
            voltageMv = voltageMv,
            currentNowUa = currentNow
        )
    }

    fun getStorageSnapshot(): Pair<Long, Long> {
        val path = Environment.getDataDirectory()
        val stat = StatFs(path.path)
        val blockSize = stat.blockSizeLong
        val totalBytes = stat.blockCountLong * blockSize
        val availableBytes = stat.availableBlocksLong * blockSize
        return Pair(totalBytes, availableBytes)
    }

    fun getCpuCoreCount(): Int {
        return Runtime.getRuntime().availableProcessors()
    }

    fun getSocModel(): String {
        return Build.HARDWARE.uppercase() + " / " + Build.SOC_MODEL.ifEmpty { Build.BOARD }
    }
}