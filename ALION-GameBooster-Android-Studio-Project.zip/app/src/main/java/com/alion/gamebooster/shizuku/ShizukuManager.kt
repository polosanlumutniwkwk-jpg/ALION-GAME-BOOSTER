package com.alion.gamebooster.shizuku

import android.content.pm.PackageManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku

/**
 * Shizuku Manager for elevated Android permissions without root.
 * Enables:
 * - Display resolution scaling (wm size)
 * - Refresh rate enforcement (settings put system min_refresh_rate)
 * - Granular package background restrictions
 */
object ShizukuManager {

    private val _isAvailable = MutableStateFlow(false)
    val isAvailable: StateFlow<Boolean> = _isAvailable.asStateFlow()

    private val _hasPermission = MutableStateFlow(false)
    val hasPermission: StateFlow<Boolean> = _hasPermission.asStateFlow()

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == 2001) {
            _hasPermission.value = grantResult == PackageManager.PERMISSION_GRANTED
        }
    }

    fun init() {
        try {
            Shizuku.addRequestPermissionResultListener(permissionListener)
            checkStatus()
        } catch (_: Throwable) {
            _isAvailable.value = false
        }
    }

    fun checkStatus() {
        try {
            val alive = Shizuku.pingBinder()
            _isAvailable.value = alive
            if (alive) {
                _hasPermission.value = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }
        } catch (_: Exception) {
            _isAvailable.value = false
            _hasPermission.value = false
        }
    }

    fun requestPermission() {
        if (_isAvailable.value && !_hasPermission.value) {
            Shizuku.requestPermission(2001)
        }
    }

    /**
     * Executes privileged commands using Shizuku remote process
     */
    fun executePrivilegedCommand(cmd: String): String {
        return try {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", cmd), null, null)
            val output = process.inputStream.bufferedReader().readText()
            process.waitFor()
            output
        } catch (e: Exception) {
            "Error: ${e.localizedMessage}"
        }
    }
}